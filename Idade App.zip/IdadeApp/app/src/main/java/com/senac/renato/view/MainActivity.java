package com.senac.renato.view;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.senac.renato.R;
import com.senac.renato.model.Pessoa;
import com.senac.renato.model.PessoaBO;

public class MainActivity extends AppCompatActivity {

    private EditText editNome;
    private EditText editIdade;
    private TextView tvResultado;
    private LinearLayout layoutResultado;

    //Adicionar evento de click no botão
    private Button btnFechar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initialize();
    }

    private void initialize(){
        editNome = findViewById(R.id.editNome);
        editIdade = findViewById(R.id.editIdade);
        tvResultado = findViewById(R.id.tvResultado);
        layoutResultado = findViewById(R.id.layoutResultado);

        //Inserção do evento onClickListener no botão fechar
        btnFechar = findViewById(R.id.btnFechar);
        btnFechar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fecharAction();
            }
        });
    }

    private void fecharAction(){
        AlertDialog.Builder alerta = new AlertDialog.Builder(this);
        alerta.setTitle(R.string.fechando_app);
        alerta.setMessage(R.string.questao_fechar_app);
        alerta.setNegativeButton(R.string.nao, null);
        alerta.setPositiveButton(R.string.sim, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(MainActivity.this, "Clicou em fechar", Toast.LENGTH_SHORT).show();
                MainActivity.this.finish();
            }
        });
        alerta.setNeutralButton("Limpar tela", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                limparTela();
            }
        });
        alerta.show();
    }

    public void verificar(View v){
        Pessoa pessoa = new Pessoa();
        pessoa.setNome(editNome.getText().toString());
        pessoa.setIdade(editIdade.getText().toString());

        if(!PessoaBO.validarNome(pessoa.getNome())){
            Toast.makeText(this, getString(R.string.erro_nome), Toast.LENGTH_SHORT).show();
            editNome.setError(getString(R.string.erro_nome));
        } else if(!PessoaBO.validarIdade(pessoa.getIdade())){
            editIdade.setError(getString(R.string.erro_idade));
        } else {
            //Elemento estático
            tvResultado.setText("Olá " + pessoa.getNome() + ", você possui " + pessoa.getIdade() + " ano(s)" );

            //Adicionando saida dinâmica
            ImageView ivResultado = new ImageView(this);
            if(PessoaBO.verificarMaioridade(pessoa.getIdade())){
                ivResultado.setImageResource(R.drawable.maior_idade);
            } else {
                ivResultado.setImageResource(R.drawable.menor_idade);
            }
            layoutResultado.removeAllViews();
            layoutResultado.addView(ivResultado);
            limparForm();
        }
    }

    private void limparForm(){
        editNome.setText("");
        editIdade.setText("");
    }

    private void limparTela(){
        limparForm();
        tvResultado.setText("");
        layoutResultado.removeAllViews();
    }


    public void ir(View v){
        Intent it = new Intent(this, SobreActivity.class);
        startActivity(it);
    }

}
