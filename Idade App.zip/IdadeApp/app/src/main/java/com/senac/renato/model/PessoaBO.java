package com.senac.renato.model;

/**
 * Classe responsável pelas ações com Pesssoa.
 */
public class PessoaBO {
    /**
     * Validar nome
     * @param nome
     * @return
     */
    public static boolean validarNome(String nome){
        return nome!=null && !nome.equals("");
    }

    public static boolean validarIdade(Integer idade){
        return idade!=null && idade>=0 && idade<200;
    }

    public static boolean verificarMaioridade(Integer idade){
        return idade >= 18;
    }
}